Newran02 C++ random number generator library.

This updates newran to bring it in line with newmat09, includes some
additional distributions and improves the documentation. Newran02A
updates the exception library and the make files and removes an
incompatibility with MS VC++ 5

Documentation is in nr02doc.htm.

